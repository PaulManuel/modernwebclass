let x;
let y;
let z;
x = 10;
y = "10";
z = 30;

console.log("x is of type " + typeof x);
console.log("y is of type " + typeof y);
console.log("z is of type " + typeof z);

var newX = x++;

console.log("newX is " + newX);
console.log(x);
console.log("Does X equate to Y?  " + (x == y));

