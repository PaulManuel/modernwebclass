# Chapter 5: Conditionals 
## Steps

1. In `WIP/js` create a file called `conditionals.js` and do your work in this file. 

1. Declare numOne to be a numeric 1.
(Scroll for answer and to continue)

    ```javascript






















    let numOne = 1;
    ```

1. Declare stringOne to be a string '1'.
(Scroll for answer and to continue)

    ```javascript






















    let stringOne = '1';
    ```

1. Think about the ouput will be for these two statements. Add these to your code and run - is it as you expect?
    ```javascript
    console.log('double ==', numOne == stringOne);
    console.log('triple ===', numOne === stringOne);
    ```

## Bonus

1. Use conditional logic and console.log to complete the following. If you need help refer to the demos.  

1. Find out the day of the week.
    ```javascript
    const day = new Date().getDay();
    //  0 = Sunday 1 = Monday ....  6 = Saturday
    ```

1. If today is Monday, display "Back to work!"
    If today is Wedneday, display "Over the hump!"
    If today is Saturday or Sunday, display "It is the weekend!"
    For all other days, display "It is a weekday".

