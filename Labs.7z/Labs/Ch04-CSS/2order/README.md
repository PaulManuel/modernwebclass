# Chapter 4: Order is important!

### Estimated Completion Time 
5 minutes
 
1. If you needed to step away or otherwise did not finish the exercise, please rename your CSS directory to CSSIncomplete, and copy solution from last chapter into your WIP directory to continue from there 

1. Continue working in `CSS` 

1. It is no longer fake Halloween - comment out that stylesheet.


1. Style the links in the nav tag (can refer to slides)
    * Set the normal state to have a white text color and background color of red
    * On a hover switch the two 
    * Keep in mind LoVe HAte

